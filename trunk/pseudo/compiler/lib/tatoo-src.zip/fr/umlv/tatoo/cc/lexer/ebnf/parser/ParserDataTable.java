package fr.umlv.tatoo.cc.lexer.ebnf.parser;

import fr.umlv.tatoo.cc.lexer.ebnf.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.TerminalEnum;
import fr.umlv.tatoo.runtime.parser.AcceptAction;
import fr.umlv.tatoo.runtime.parser.Action;
import fr.umlv.tatoo.runtime.parser.BranchAction;
import fr.umlv.tatoo.runtime.parser.ErrorAction;
import fr.umlv.tatoo.runtime.parser.ExitAction;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.parser.ReduceAction;
import fr.umlv.tatoo.runtime.parser.ShiftAction;
import fr.umlv.tatoo.runtime.parser.StateMetadata;
import java.util.EnumMap;

/** 
 *  This class is generated - please do not edit it 
 */
public class ParserDataTable {
  private ParserDataTable() {
   accept = AcceptAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
   exit = ExitAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    initprodsGotoes();
    initterminal_or_prod_priorityGotoes();
    inittypes_lhs_optional_8Gotoes();
    initlexemGotoes();
    initerror_lhs_optional_6Gotoes();
    initimport_Gotoes();
    initregexGotoes();
    initversion_listGotoes();
    initvariableGotoes();
    inittype_optional_18Gotoes();
    initcomments_listGotoes();
    initdeclGotoes();
    initterminal_or_prod_priority_optional_14Gotoes();
    initqmark_optional_23Gotoes();
    initpriorities_lhs_optional_2Gotoes();
    initstart_non_terminalsGotoes();
    initvarlistGotoes();
    initcomment_lhs_optional_4Gotoes();
    initseparator_optional_26Gotoes();
    initbranch_lexemGotoes();
    initpriorities_lhsGotoes();
    initblank_lhs_optional_3Gotoes();
    initbanches_listGotoes();
    initproduction_version_optional_21Gotoes();
    initparent_version_optional_10Gotoes();
    initcomment_lexemGotoes();
    initterminal_or_prod_priority_optional_16Gotoes();
    initvartypedefGotoes();
    initdirectives_lhsGotoes();
    initdirectives_lhs_optional_0Gotoes();
    initvargroupGotoes();
    initcomment_lhsGotoes();
    initversions_optional_7Gotoes();
    initaliasGotoes();
    initblank_lexemGotoes();
    initterminal_or_prod_priority_optional_17Gotoes();
    initregex_terminal_decl_optional_13Gotoes();
    initstartidGotoes();
    initproduction_lhsGotoes();
    initseparator_optional_25Gotoes();
    initerror_lhsGotoes();
    initvartypedef_listGotoes();
    initblank_lhsGotoes();
    initbranch_lhs_optional_5Gotoes();
    initdeclsGotoes();
    initregex_terminal_declGotoes();
    initimports_lhs_optional_1Gotoes();
    inittype_optional_15Gotoes();
    initvarGotoes();
    initproduction_idGotoes();
    inittypeGotoes();
    initblanks_listGotoes();
    inittype_optional_12Gotoes();
    initpriority_listGotoes();
    initdirectiveGotoes();
    initproduction_versionGotoes();
    initbranch_lhsGotoes();
    initstart_non_terminals_optional_9Gotoes();
    initalias_optional_11Gotoes();
    inittypes_lhsGotoes();
    initseparator_optional_27Gotoes();
    initqmark_optional_22Gotoes();
    initseparatorGotoes();
    initstarts_listGotoes();
    inittokens_listGotoes();
    initversionsGotoes();
    initstartGotoes();
    initprodGotoes();
    initparent_versionGotoes();
    initterminal_or_prod_priority_optional_19Gotoes();
    initversionGotoes();
    initpriorityGotoes();
    inittoken_lhsGotoes();
    initimport_listGotoes();
    initimports_lhsGotoes();
    initdirective_listGotoes();
    initseparator_optional_24Gotoes();
    initproduction_id_optional_20Gotoes();
    reduceseparator_optional_24_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_24_separator,1,separator_optional_24Gotoes);
    reducevar_nonterminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal,2,varGotoes);
    reduceimports_lhs_optional_1_imports_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_lhs_optional_1_imports_lhs,1,imports_lhs_optional_1Gotoes);
    reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_19_terminal_or_prod_priority,1,terminal_or_prod_priority_optional_19Gotoes);
    reducetoken_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.token_def,3,token_lhsGotoes);
    reducetype_optional_12_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_12_empty,0,type_optional_12Gotoes);
    reduceproduction_id_optional_20_production_id = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id_optional_20_production_id,1,production_id_optional_20Gotoes);
    reduceimport_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_def,1,import_Gotoes);
    reduceparent_version_optional_10_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_optional_10_empty,0,parent_version_optional_10Gotoes);
    reduceterminal_or_prod_priority_optional_19_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_19_empty,0,terminal_or_prod_priority_optional_19Gotoes);
    reducebranch_eof_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_eof_terminal,2,branch_lexemGotoes);
    reducealias_optional_11_alias = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_optional_11_alias,1,alias_optional_11Gotoes);
    reduceprods_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prods_rec,3,prodsGotoes);
    reduceversions_optional_7_versions = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_optional_7_versions,1,versions_optional_7Gotoes);
    reducevar_terminal_star = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal_star,3,varGotoes);
    reducestartid_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.startid_def,1,startidGotoes);
    reducealias_optional_11_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_optional_11_empty,0,alias_optional_11Gotoes);
    reduceblanks_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blanks_list_empty,0,blanks_listGotoes);
    reducedirective_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_def,1,directiveGotoes);
    reduceblank_lexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lexem_terminal,3,blank_lexemGotoes);
    reducevartypedef_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartypedef_list_rec,2,vartypedef_listGotoes);
    reducestarts_list_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.starts_list_element,1,starts_listGotoes);
    reduceseparator_optional_25_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_25_empty,0,separator_optional_25Gotoes);
    reducetokens_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.tokens_list_empty,0,tokens_listGotoes);
    reducecomments_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comments_list_empty,0,comments_listGotoes);
    reducedirectives_lhs_optional_0_directives_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_lhs_optional_0_directives_lhs,1,directives_lhs_optional_0Gotoes);
    reduceseparator_optional_27_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_27_empty,0,separator_optional_27Gotoes);
    reduceblank_lexem_macro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lexem_macro,4,blank_lexemGotoes);
    reducevariable_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.variable_terminal,3,variableGotoes);
    reduceversions_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_def,3,versionsGotoes);
    reduceversions_optional_7_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.versions_optional_7_empty,0,versions_optional_7Gotoes);
    reducepriority_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_def,4,priorityGotoes);
    reduceerror_lhs_optional_6_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_lhs_optional_6_empty,0,error_lhs_optional_6Gotoes);
    reducecomment_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comment_def,3,comment_lhsGotoes);
    reduceseparator_optional_26_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_26_empty,0,separator_optional_26Gotoes);
    reducetype_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_def,2,typeGotoes);
    reduceterminal_or_prod_priority_optional_16_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_16_empty,0,terminal_or_prod_priority_optional_16Gotoes);
    reducevartypedef_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartypedef_list_empty,0,vartypedef_listGotoes);
    reduceqmark_optional_22_qmark = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional_22_qmark,1,qmark_optional_22Gotoes);
    reduceregex_quote = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_quote,3,regexGotoes);
    reducepriorities_lhs_optional_2_priorities_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_lhs_optional_2_priorities_lhs,1,priorities_lhs_optional_2Gotoes);
    reduceqmark_optional_22_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional_22_empty,0,qmark_optional_22Gotoes);
    reduceversion_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_list_empty,0,version_listGotoes);
    reducepriority_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_list_empty,0,priority_listGotoes);
    reduceseparator_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_terminal,4,separatorGotoes);
    reduceseparator_non_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_non_terminal,2,separatorGotoes);
    reduceblanks_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blanks_list_rec,2,blanks_listGotoes);
    reduceterminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority,3,terminal_or_prod_priorityGotoes);
    reducepriorities_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_def,3,priorities_lhsGotoes);
    reducebranch_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_def,3,branch_lhsGotoes);
    reduceversion_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_def,2,versionGotoes);
    reducedirectives_lhs_optional_0_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_lhs_optional_0_empty,0,directives_lhs_optional_0Gotoes);
    reducetypes_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_def,3,types_lhsGotoes);
    reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_17_terminal_or_prod_priority,1,terminal_or_prod_priority_optional_17Gotoes);
    reducecomment_lexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comment_lexem_terminal,3,comment_lexemGotoes);
    reducetype_optional_15_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_15_type,1,type_optional_15Gotoes);
    reduceseparator_optional_26_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_26_separator,1,separator_optional_26Gotoes);
    reducestart_non_terminals_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_def,3,start_non_terminalsGotoes);
    reduceparent_version_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_def,2,parent_versionGotoes);
    reduceblank_lhs_optional_3_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lhs_optional_3_empty,0,blank_lhs_optional_3Gotoes);
    reducetokens_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.tokens_list_rec,2,tokens_listGotoes);
    reducecomment_lhs_optional_4_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comment_lhs_optional_4_empty,0,comment_lhs_optional_4Gotoes);
    reducealias_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.alias_def,3,aliasGotoes);
    reducetypes_lhs_optional_8_types_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_lhs_optional_8_types_lhs,1,types_lhs_optional_8Gotoes);
    reduceregex_doublequote = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_doublequote,3,regexGotoes);
    reducedirective_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_list_rec,2,directive_listGotoes);
    reducestart_non_terminals_optional_9_start_non_terminals = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_optional_9_start_non_terminals,1,start_non_terminals_optional_9Gotoes);
    reducevariable_nonterminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.variable_nonterminal,1,variableGotoes);
    reducevartype_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vartype_def,2,vartypedefGotoes);
    reducecomment_lexem_macro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comment_lexem_macro,4,comment_lexemGotoes);
    reducebanches_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.banches_list_empty,0,banches_listGotoes);
    reducestarts_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.starts_list_rec,2,starts_listGotoes);
    reduceproduction_version_optional_21_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version_optional_21_empty,0,production_version_optional_21Gotoes);
    reduceproduction_id_optional_20_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id_optional_20_empty,0,production_id_optional_20Gotoes);
    reducestart_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_def,12,startGotoes);
    reducetype_optional_18_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_18_type,1,type_optional_18Gotoes);
    reducevarlist_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.varlist_rec,2,varlistGotoes);
    reducetypes_lhs_optional_8_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.types_lhs_optional_8_empty,0,types_lhs_optional_8Gotoes);
    reduceblank_lhs_optional_3_blank_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_lhs_optional_3_blank_lhs,1,blank_lhs_optional_3Gotoes);
    reducecomment_lhs_optional_4_comment_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comment_lhs_optional_4_comment_lhs,1,comment_lhs_optional_4Gotoes);
    reduceproduction_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version,2,production_versionGotoes);
    reduceproduction_version_optional_21_production_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_version_optional_21_production_version,1,production_version_optional_21Gotoes);
    reduceseparator_optional_27_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_27_separator,1,separator_optional_27Gotoes);
    reducecomments_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.comments_list_rec,2,comments_listGotoes);
    reducevar_group = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_group,3,varGotoes);
    reduceerror_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_def,3,error_lhsGotoes);
    reducepriority_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priority_list_rec,2,priority_listGotoes);
    reduceimports_lhs_optional_1_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_lhs_optional_1_empty,0,imports_lhs_optional_1Gotoes);
    reducelexem_macro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.lexem_macro,4,lexemGotoes);
    reduceprods_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prods_element,1,prodsGotoes);
    reduceterminal_or_prod_priority_optional_14_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_14_empty,0,terminal_or_prod_priority_optional_14Gotoes);
    reduceterminal_or_prod_priority_optional_17_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_17_empty,0,terminal_or_prod_priority_optional_17Gotoes);
    reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_14_terminal_or_prod_priority,1,terminal_or_prod_priority_optional_14Gotoes);
    reduceversion_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.version_list_rec,2,version_listGotoes);
    reducetype_optional_12_type = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_12_type,1,type_optional_12Gotoes);
    reducebranch_lexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lexem_terminal,3,branch_lexemGotoes);
    reduceerror_lhs_optional_6_error_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.error_lhs_optional_6_error_lhs,1,error_lhs_optional_6Gotoes);
    reducepriorities_lhs_optional_2_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.priorities_lhs_optional_2_empty,0,priorities_lhs_optional_2Gotoes);
    reducedecls_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decls_empty,0,declsGotoes);
    reduceregex_terminal_decl_optional_13_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl_optional_13_empty,0,regex_terminal_decl_optional_13Gotoes);
    reducedirective_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directive_list_empty,0,directive_listGotoes);
    reducestart_non_terminals_optional_9_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.start_non_terminals_optional_9_empty,0,start_non_terminals_optional_9Gotoes);
    reducedecl_productions = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decl_productions,5,declGotoes);
    reducevar_nonterminal_star = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal_star,3,varGotoes);
    reducedirectives_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.directives_def,3,directives_lhsGotoes);
    reducevargroup_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vargroup_rec,2,vargroupGotoes);
    reduceblank_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.blank_def,3,blank_lhsGotoes);
    reducetype_optional_15_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_15_empty,0,type_optional_15Gotoes);
    reducebranch_lhs_optional_5_branch_lhs = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lhs_optional_5_branch_lhs,1,branch_lhs_optional_5Gotoes);
    reducevarlist_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.varlist_empty,0,varlistGotoes);
    reducelexem_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.lexem_terminal,5,lexemGotoes);
    reduceregex_terminal_decl = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl,2,regex_terminal_declGotoes);
    reduceqmark_optional_23_qmark = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional_23_qmark,1,qmark_optional_23Gotoes);
    reduceseparator_optional_24_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_24_empty,0,separator_optional_24Gotoes);
    reduceprod_production = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.prod_production,3,prodGotoes);
    reduceregex_terminal_decl_optional_13_regex_terminal_decl = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regex_terminal_decl_optional_13_regex_terminal_decl,1,regex_terminal_decl_optional_13Gotoes);
    reducedecls_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.decls_rec,2,declsGotoes);
    reducevar_nonterminal_plus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_nonterminal_plus,3,varGotoes);
    reduceseparator_optional_25_separator = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.separator_optional_25_separator,1,separator_optional_25Gotoes);
    reduceproduction_id = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_id,4,production_idGotoes);
    reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.terminal_or_prod_priority_optional_16_terminal_or_prod_priority,1,terminal_or_prod_priority_optional_16Gotoes);
    reduceimports_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.imports_def,3,imports_lhsGotoes);
    reduceimport_list_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_list_empty,0,import_listGotoes);
    reduceparent_version_optional_10_parent_version = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.parent_version_optional_10_parent_version,1,parent_version_optional_10Gotoes);
    reducevar_terminal_plus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal_plus,3,varGotoes);
    reduceproduction_def = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.production_def,3,production_lhsGotoes);
    reducetype_optional_18_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.type_optional_18_empty,0,type_optional_18Gotoes);
    reducebanches_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.banches_list_rec,2,banches_listGotoes);
    reduceimport_list_rec = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.import_list_rec,2,import_listGotoes);
    reduceqmark_optional_23_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.qmark_optional_23_empty,0,qmark_optional_23Gotoes);
    reducevargroup_element = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.vargroup_element,1,vargroupGotoes);
    reducevar_terminal = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.var_terminal,2,varGotoes);
    reducebranch_lhs_optional_5_empty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.branch_lhs_optional_5_empty,0,branch_lhs_optional_5Gotoes);
    shift23 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(23);
    shift39 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(39);
    shift64 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(64);
    shift101 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(101);
    shift159 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(159);
    shift49 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(49);
    shift139 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(139);
    shift31 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(31);
    shift171 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(171);
    shift142 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(142);
    shift117 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(117);
    shift78 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(78);
    shift61 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(61);
    shift104 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(104);
    shift132 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(132);
    shift155 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(155);
    shift174 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(174);
    shift4 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(4);
    shift65 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(65);
    shift82 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(82);
    shift127 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(127);
    shift147 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(147);
    shift1 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(1);
    shift13 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(13);
    shift118 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(118);
    shift17 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(17);
    shift126 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(126);
    shift30 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(30);
    shift56 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(56);
    shift163 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(163);
    shift153 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(153);
    shift120 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(120);
    shift50 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(50);
    shift144 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(144);
    shift114 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(114);
    shift150 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(150);
    shift107 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(107);
    shift108 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(108);
    shift140 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(140);
    shift74 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(74);
    shift20 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(20);
    shift27 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(27);
    shift89 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(89);
    shift75 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(75);
    shift22 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(22);
    shift135 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(135);
    shift33 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(33);
    shift133 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(133);
    shift42 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(42);
    shift160 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(160);
    shift67 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(67);
    shift32 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(32);
    shift44 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(44);
    shift55 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(55);
    shift81 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(81);
    shift41 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(41);
    shift68 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(68);
    shift141 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(141);
    shift152 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(152);
    shift100 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(100);
    shift125 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(125);
    shift115 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(115);
    shift57 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(57);
    shift179 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(179);
    shift18 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(18);
    shift86 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(86);
    shift10 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(10);
    shift168 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(168);
    shift11 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(11);
    shift145 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(145);
    shift109 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(109);
    shift80 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(80);
    shift169 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(169);
    shift143 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(143);
    shift43 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(43);
    shift62 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(62);
    shift105 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(105);
    shift51 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(51);
    shift45 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(45);
    shift21 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(21);
    shift28 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(28);
    shift87 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(87);
    shift36 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(36);
    shift94 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(94);
    shift77 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(77);
    shift2 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(2);
    shift178 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(178);
    shift69 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(69);
    shift170 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(170);
    shift119 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(119);
    shift99 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(99);
    shift37 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(37);
    shift40 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(40);
    shift137 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(137);
    error0 = new ErrorAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    branch0 = new BranchAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    initidArray();
    inittokensdeclArray();
    initqmarkArray();
    inittypesdeclArray();
    initerrordeclArray();
    initversionsdeclArray();
    initimportsdeclArray();
    initstartsdeclArray();
    initnumberArray();
    initqualifiedidArray();
    initrbracketArray();
    initlsqbracketArray();
    initsemicolonArray();
    initrsqbracketArray();
    initplusArray();
    initbranchesdeclArray();
    initcolonArray();
    initquoteArray();
    initprioritiesdeclArray();
    initstarArray();
    initlbracketArray();
    initassocArray();
    initdirectivesdeclArray();
    initslashArray();
    initregexdoublequoteArray();
    initrparArray();
    initeofArray();
    initlparArray();
    initpipeArray();
    initquoted_nameArray();
    initdollarArray();
    initcommentsdeclArray();
    init__eof__Array();
    initdoublequoteArray();
    initassignArray();
    initproductionsdeclArray();
    initblanksdeclArray();
    initregexquoteArray();
    EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]> tableMap =
      new EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]>(TerminalEnum.class);
      
    tableMap.put(TerminalEnum.id,idArray);
    tableMap.put(TerminalEnum.tokensdecl,tokensdeclArray);
    tableMap.put(TerminalEnum.qmark,qmarkArray);
    tableMap.put(TerminalEnum.typesdecl,typesdeclArray);
    tableMap.put(TerminalEnum.errordecl,errordeclArray);
    tableMap.put(TerminalEnum.versionsdecl,versionsdeclArray);
    tableMap.put(TerminalEnum.importsdecl,importsdeclArray);
    tableMap.put(TerminalEnum.startsdecl,startsdeclArray);
    tableMap.put(TerminalEnum.number,numberArray);
    tableMap.put(TerminalEnum.qualifiedid,qualifiedidArray);
    tableMap.put(TerminalEnum.rbracket,rbracketArray);
    tableMap.put(TerminalEnum.lsqbracket,lsqbracketArray);
    tableMap.put(TerminalEnum.semicolon,semicolonArray);
    tableMap.put(TerminalEnum.rsqbracket,rsqbracketArray);
    tableMap.put(TerminalEnum.plus,plusArray);
    tableMap.put(TerminalEnum.branchesdecl,branchesdeclArray);
    tableMap.put(TerminalEnum.colon,colonArray);
    tableMap.put(TerminalEnum.quote,quoteArray);
    tableMap.put(TerminalEnum.prioritiesdecl,prioritiesdeclArray);
    tableMap.put(TerminalEnum.star,starArray);
    tableMap.put(TerminalEnum.lbracket,lbracketArray);
    tableMap.put(TerminalEnum.assoc,assocArray);
    tableMap.put(TerminalEnum.directivesdecl,directivesdeclArray);
    tableMap.put(TerminalEnum.slash,slashArray);
    tableMap.put(TerminalEnum.regexdoublequote,regexdoublequoteArray);
    tableMap.put(TerminalEnum.rpar,rparArray);
    tableMap.put(TerminalEnum.eof,eofArray);
    tableMap.put(TerminalEnum.lpar,lparArray);
    tableMap.put(TerminalEnum.pipe,pipeArray);
    tableMap.put(TerminalEnum.quoted_name,quoted_nameArray);
    tableMap.put(TerminalEnum.dollar,dollarArray);
    tableMap.put(TerminalEnum.commentsdecl,commentsdeclArray);
    tableMap.put(TerminalEnum.__eof__,__eof__Array);
    tableMap.put(TerminalEnum.doublequote,doublequoteArray);
    tableMap.put(TerminalEnum.assign,assignArray);
    tableMap.put(TerminalEnum.productionsdecl,productionsdeclArray);
    tableMap.put(TerminalEnum.blanksdecl,blanksdeclArray);
    tableMap.put(TerminalEnum.regexquote,regexquoteArray);
    initBranchArrayTable();
    
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] tableMetadata = createStateMetadataTable();
    
    EnumMap<NonTerminalEnum,Integer> tableStarts =
      new EnumMap<NonTerminalEnum,Integer>(NonTerminalEnum.class);
    tableStarts.put(NonTerminalEnum.start,0);
    table = new ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>(tableMap,branchArrayTable,tableMetadata,tableStarts,VersionEnum.values(),190,TerminalEnum.__eof__,null);
  } 

  @SuppressWarnings("unchecked")
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] createStateMetadataTable() {
         
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0version_metadata0reduceversion_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.version,reduceversion_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0types_lhs_optional_8_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.types_lhs_optional_8,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0production_version_optional_21_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_version_optional_21,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0plus_metadata0reducevar_nonterminal_plus = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus,reducevar_nonterminal_plus);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducevartypedef_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducevartypedef_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0__eof___metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.__eof__,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0blank_lhs_metadata0reduceblank_lhs_optional_3_blank_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lhs,reduceblank_lhs_optional_3_blank_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0types_lhs_metadata0reducetypes_lhs_optional_8_types_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.types_lhs,reducetypes_lhs_optional_8_types_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reduceblanks_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reduceblanks_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reduceversion_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reduceversion_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rsqbracket_metadata0reduceterminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rsqbracket,reduceterminal_or_prod_priority);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_optional_17_metadata0reducebranch_eof_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional_17,reducebranch_eof_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reducevariable_nonterminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reducevariable_nonterminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comment_lhs_metadata0reducecomment_lhs_optional_4_comment_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.comment_lhs,reducecomment_lhs_optional_4_comment_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0versionsdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.versionsdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0tokensdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.tokensdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0typesdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.typesdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0separator_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qualifiedid_metadata0reduceimport_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qualifiedid,reduceimport_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0reducevariable_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,reducevariable_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qmark_optional_23_metadata0reducevar_nonterminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.qmark_optional_23,reducevar_nonterminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0priorities_lhs_metadata0reducepriorities_lhs_optional_2_priorities_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priorities_lhs,reducepriorities_lhs_optional_2_priorities_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0directive_metadata0reducedirective_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directive,reducedirective_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reduceparent_version_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reduceparent_version_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reduceseparator_non_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reduceseparator_non_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0startid_metadata0reducestarts_list_element = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.startid,reducestarts_list_element);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0start_non_terminals_metadata0reducestart_non_terminals_optional_9_start_non_terminals = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start_non_terminals,reducestart_non_terminals_optional_9_start_non_terminals);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0assign_metadata0reducevarlist_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.assign,reducevarlist_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0prod_metadata0reduceprods_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.prod,reduceprods_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lpar_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lpar,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_optional_14_metadata0reducelexem_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional_14,reducelexem_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0vartypedef_metadata0reducevartypedef_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vartypedef,reducevartypedef_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0alias_optional_11_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.alias_optional_11,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducedirective_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducedirective_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_terminal_decl_optional_13_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex_terminal_decl_optional_13,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0directive_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directive_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0prioritiesdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.prioritiesdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0blank_lhs_optional_3_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lhs_optional_3,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0plus_metadata0reducevar_terminal_plus = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus,reducevar_terminal_plus);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qmark_optional_22_metadata0reducevar_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.qmark_optional_22,reducevar_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0varlist_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.varlist,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0importsdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.importsdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0production_id_metadata0reduceproduction_id_optional_20_production_id = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_id,reduceproduction_id_optional_20_production_id);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0error_lhs_optional_6_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.error_lhs_optional_6,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reduceblank_lexem_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reduceblank_lexem_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0blank_lexem_metadata0reduceblanks_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blank_lexem,reduceblanks_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0null_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(null,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reduceblank_lexem_macro = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reduceblank_lexem_macro);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0productionsdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.productionsdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_metadata0reducevartype_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type,reducevartype_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0start_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0priority_metadata0reducepriority_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priority,reducepriority_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0branchesdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.branchesdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0dollar_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dollar,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0token_lhs_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.token_lhs,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0banches_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.banches_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qualifiedid_metadata0reducetype_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qualifiedid,reducetype_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0branch_lhs_optional_5_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lhs_optional_5,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lbracket_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbracket,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0alias_metadata0reducealias_optional_11_alias = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.alias,reducealias_optional_11_alias);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_optional_12_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional_12,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0variable_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.variable,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0imports_lhs_optional_1_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.imports_lhs_optional_1,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0startsdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.startsdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reduceproduction_version = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reduceproduction_version);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_metadata0reducetype_optional_15_type = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type,reducetype_optional_15_type);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0vargroup_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vargroup,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0pipe_metadata0reducevarlist_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.pipe,reducevarlist_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0versions_metadata0reduceversions_optional_7_versions = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.versions,reduceversions_optional_7_versions);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0star_metadata0reducevar_terminal_star = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star,reducevar_terminal_star);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0separator_optional_25_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional_25,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_optional_16_metadata0reducebranch_lexem_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional_16,reducebranch_lexem_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0slash_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.slash,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0reduceregex_quote = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,reduceregex_quote);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0branch_lexem_metadata0reducebanches_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lexem,reducebanches_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0separator_optional_27_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional_27,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0starts_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.starts_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comment_lexem_metadata0reducecomments_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.comment_lexem,reducecomments_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_optional_18_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional_18,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducepriority_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducepriority_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0var_metadata0reducevargroup_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.var,reducevargroup_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducedecls_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducedecls_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_metadata0reducetype_optional_18_type = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type,reducetype_optional_18_type);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0var_metadata0reducevargroup_element = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.var,reducevargroup_element);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0directives_lhs_optional_0_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directives_lhs_optional_0,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qmark_metadata0reduceqmark_optional_22_qmark = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qmark,reduceqmark_optional_22_qmark);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0start_non_terminals_optional_9_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.start_non_terminals_optional_9,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reduceregex_terminal_decl = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reduceregex_terminal_decl);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0branch_lhs_metadata0reducebranch_lhs_optional_5_branch_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.branch_lhs,reducebranch_lhs_optional_5_branch_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0startid_metadata0reducestarts_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.startid,reducestarts_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rpar_metadata0reducealias_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar,reducealias_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0number_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.number,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0errordecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.errordecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0imports_lhs_metadata0reduceimports_lhs_optional_1_imports_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.imports_lhs,reduceimports_lhs_optional_1_imports_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0decl_metadata0reducedecls_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.decl,reducedecls_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0prods_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.prods,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regexquote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.regexquote,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0import_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.import_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0commentsdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.commentsdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0separator_optional_24_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional_24,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quoted_name_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quoted_name,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reducecomment_lexem_macro = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reducecomment_lexem_macro);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lsqbracket_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lsqbracket,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lexem_metadata0reducetokens_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.lexem,reducetokens_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0doublequote_metadata0reduceregex_doublequote = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.doublequote,reduceregex_doublequote);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reducedirective_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reducedirective_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0priorities_lhs_optional_2_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priorities_lhs_optional_2,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0blanksdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.blanksdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0separator_optional_26_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.separator_optional_26,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reduceimport_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reduceimport_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0parent_version_metadata0reduceparent_version_optional_10_parent_version = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.parent_version,reduceparent_version_optional_10_parent_version);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0qmark_metadata0reduceqmark_optional_23_qmark = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.qmark,reduceqmark_optional_23_qmark);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0import__metadata0reduceimport_list_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.import_,reduceimport_list_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0var_metadata0reducevarlist_rec = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.var,reducevarlist_rec);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0eof_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.eof,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0vartypedef_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.vartypedef_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducebanches_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducebanches_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0decls_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.decls,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0production_version_metadata0reduceproduction_version_optional_21_production_version = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_version,reduceproduction_version_optional_21_production_version);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_optional_19_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority_optional_19,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducetokens_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducetokens_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0assoc_metadata0reducepriority_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.assoc,reducepriority_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0assign_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.assign,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0versions_optional_7_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.versions_optional_7,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0directives_lhs_metadata0reducedirectives_lhs_optional_0_directives_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.directives_lhs,reducedirectives_lhs_optional_0_directives_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0doublequote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.doublequote,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reducelexem_macro = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reducelexem_macro);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reducestartid_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reducestartid_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0directivesdecl_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.directivesdecl,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rpar_metadata0reducevar_group = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar,reducevar_group);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comment_lhs_optional_4_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.comment_lhs_optional_4,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0reducecomment_lexem_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,reducecomment_lexem_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0semicolon_metadata0reducedecl_productions = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.semicolon,reducedecl_productions);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0star_metadata0reducevar_nonterminal_star = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star,reducevar_nonterminal_star);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0id_metadata0reduceerror_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.id,reduceerror_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0error_lhs_metadata0reduceerror_lhs_optional_6_error_lhs = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.error_lhs,reduceerror_lhs_optional_6_error_lhs);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0reduceseparator_terminal = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,reduceseparator_terminal);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0tokens_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.tokens_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0priority_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.priority_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0blanks_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.blanks_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0version_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.version_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_optional_15_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type_optional_15,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comments_list_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.comments_list,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regexdoublequote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.regexdoublequote,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_terminal_decl_metadata0reduceregex_terminal_decl_optional_13_regex_terminal_decl = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbracket_metadata0reduceproduction_id = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbracket,reduceproduction_id);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority,reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0type_metadata0reducetype_optional_12_type = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.type,reducetype_optional_12_type);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0production_lhs_metadata0reducestart_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_lhs,reducestart_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0colon_metadata0reducecomments_list_empty = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.colon,reducecomments_list_empty);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0parent_version_optional_10_metadata0reduceversion_def = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.parent_version_optional_10,reduceversion_def);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0prod_metadata0reduceprods_element = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.prod,reduceprods_element);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.terminal_or_prod_priority,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0production_id_optional_20_metadata0reduceprod_production = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.production_id_optional_20,reduceprod_production);

    return (StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[])new StateMetadata<?,?,?,?>[]{metadata0null_metadata0null,metadata0directivesdecl_metadata0null,metadata0colon_metadata0reducedirective_list_empty,metadata0directive_list_metadata0null,metadata0id_metadata0reducedirective_def,metadata0directive_metadata0reducedirective_list_rec,metadata0directives_lhs_metadata0reducedirectives_lhs_optional_0_directives_lhs,metadata0start_metadata0null,metadata0__eof___metadata0null,metadata0directives_lhs_optional_0_metadata0null,metadata0importsdecl_metadata0null,metadata0colon_metadata0reduceimport_list_empty,metadata0import_list_metadata0null,metadata0qualifiedid_metadata0reduceimport_def,metadata0import__metadata0reduceimport_list_rec,metadata0imports_lhs_metadata0reduceimports_lhs_optional_1_imports_lhs,metadata0imports_lhs_optional_1_metadata0null,metadata0prioritiesdecl_metadata0null,metadata0colon_metadata0reducepriority_list_empty,metadata0priority_list_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0number_metadata0null,metadata0assoc_metadata0reducepriority_def,metadata0priority_metadata0reducepriority_list_rec,metadata0priorities_lhs_metadata0reducepriorities_lhs_optional_2_priorities_lhs,metadata0priorities_lhs_optional_2_metadata0null,metadata0tokensdecl_metadata0null,metadata0colon_metadata0reducetokens_list_empty,metadata0tokens_list_metadata0null,metadata0id_metadata0null,metadata0lpar_metadata0null,metadata0quoted_name_metadata0null,metadata0rpar_metadata0reducealias_def,metadata0alias_metadata0reducealias_optional_11_alias,metadata0alias_optional_11_metadata0null,metadata0colon_metadata0null,metadata0qualifiedid_metadata0reducetype_def,metadata0type_optional_12_metadata0null,metadata0assign_metadata0null,metadata0doublequote_metadata0null,metadata0regexdoublequote_metadata0null,metadata0doublequote_metadata0reduceregex_doublequote,metadata0quote_metadata0null,metadata0regexquote_metadata0null,metadata0quote_metadata0reduceregex_quote,metadata0regex_metadata0reduceregex_terminal_decl,metadata0regex_terminal_decl_metadata0reduceregex_terminal_decl_optional_13_regex_terminal_decl,metadata0regex_terminal_decl_optional_13_metadata0null,metadata0lsqbracket_metadata0null,metadata0id_metadata0null,metadata0rsqbracket_metadata0reduceterminal_or_prod_priority,metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,metadata0terminal_or_prod_priority_optional_14_metadata0reducelexem_terminal,metadata0type_metadata0reducetype_optional_12_type,metadata0dollar_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0regex_metadata0reducelexem_macro,metadata0lexem_metadata0reducetokens_list_rec,metadata0token_lhs_metadata0null,metadata0blanksdecl_metadata0null,metadata0colon_metadata0reduceblanks_list_empty,metadata0blanks_list_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0regex_metadata0reduceblank_lexem_terminal,metadata0dollar_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0regex_metadata0reduceblank_lexem_macro,metadata0blank_lexem_metadata0reduceblanks_list_rec,metadata0blank_lhs_metadata0reduceblank_lhs_optional_3_blank_lhs,metadata0blank_lhs_optional_3_metadata0null,metadata0commentsdecl_metadata0null,metadata0colon_metadata0reducecomments_list_empty,metadata0comments_list_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0regex_metadata0reducecomment_lexem_terminal,metadata0dollar_metadata0null,metadata0id_metadata0null,metadata0assign_metadata0null,metadata0regex_metadata0reducecomment_lexem_macro,metadata0comment_lexem_metadata0reducecomments_list_rec,metadata0comment_lhs_optional_4_metadata0null,metadata0branchesdecl_metadata0null,metadata0colon_metadata0reducebanches_list_empty,metadata0banches_list_metadata0null,metadata0id_metadata0null,metadata0type_optional_15_metadata0null,metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,metadata0terminal_or_prod_priority_optional_16_metadata0reducebranch_lexem_terminal,metadata0type_metadata0reducetype_optional_15_type,metadata0eof_metadata0null,metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,metadata0terminal_or_prod_priority_optional_17_metadata0reducebranch_eof_terminal,metadata0branch_lexem_metadata0reducebanches_list_rec,metadata0branch_lhs_optional_5_metadata0null,metadata0errordecl_metadata0null,metadata0colon_metadata0null,metadata0id_metadata0reduceerror_def,metadata0error_lhs_metadata0reduceerror_lhs_optional_6_error_lhs,metadata0error_lhs_optional_6_metadata0null,metadata0versionsdecl_metadata0null,metadata0colon_metadata0reduceversion_list_empty,metadata0version_list_metadata0null,metadata0id_metadata0null,metadata0colon_metadata0null,metadata0id_metadata0reduceparent_version_def,metadata0parent_version_optional_10_metadata0reduceversion_def,metadata0parent_version_metadata0reduceparent_version_optional_10_parent_version,metadata0version_metadata0reduceversion_list_rec,metadata0versions_optional_7_metadata0null,metadata0typesdecl_metadata0null,metadata0colon_metadata0reducevartypedef_list_empty,metadata0vartypedef_list_metadata0null,metadata0id_metadata0reducevariable_nonterminal,metadata0quote_metadata0null,metadata0id_metadata0null,metadata0quote_metadata0reducevariable_terminal,metadata0vartypedef_metadata0reducevartypedef_list_rec,metadata0variable_metadata0null,metadata0type_metadata0reducevartype_def,metadata0types_lhs_optional_8_metadata0null,metadata0startsdecl_metadata0null,metadata0colon_metadata0null,metadata0id_metadata0reducestartid_def,metadata0starts_list_metadata0null,metadata0startid_metadata0reducestarts_list_rec,metadata0startid_metadata0reducestarts_list_element,metadata0start_non_terminals_optional_9_metadata0null,metadata0productionsdecl_metadata0null,metadata0colon_metadata0reducedecls_empty,metadata0decls_metadata0null,metadata0id_metadata0null,metadata0type_optional_18_metadata0null,metadata0assign_metadata0reducevarlist_empty,metadata0varlist_metadata0null,metadata0id_metadata0null,metadata0slash_metadata0null,metadata0id_metadata0reduceseparator_non_terminal,metadata0quote_metadata0null,metadata0id_metadata0null,metadata0quote_metadata0reduceseparator_terminal,metadata0qmark_metadata0reduceqmark_optional_23_qmark,metadata0separator_optional_27_metadata0null,metadata0plus_metadata0reducevar_nonterminal_plus,metadata0separator_metadata0null,metadata0separator_optional_26_metadata0null,metadata0star_metadata0reducevar_nonterminal_star,metadata0qmark_optional_23_metadata0reducevar_nonterminal,metadata0quoted_name_metadata0null,metadata0qmark_metadata0reduceqmark_optional_22_qmark,metadata0separator_optional_25_metadata0null,metadata0plus_metadata0reducevar_terminal_plus,metadata0qmark_optional_22_metadata0reducevar_terminal,metadata0separator_metadata0null,metadata0separator_optional_24_metadata0null,metadata0star_metadata0reducevar_terminal_star,metadata0lpar_metadata0null,metadata0var_metadata0reducevargroup_element,metadata0vargroup_metadata0null,metadata0rpar_metadata0reducevar_group,metadata0var_metadata0reducevargroup_rec,metadata0terminal_or_prod_priority_metadata0reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority,metadata0var_metadata0reducevarlist_rec,metadata0terminal_or_prod_priority_optional_19_metadata0null,metadata0lbracket_metadata0null,metadata0id_metadata0null,metadata0colon_metadata0null,metadata0id_metadata0reduceproduction_version,metadata0production_version_metadata0reduceproduction_version_optional_21_production_version,metadata0production_version_optional_21_metadata0null,metadata0rbracket_metadata0reduceproduction_id,metadata0production_id_optional_20_metadata0reduceprod_production,metadata0production_id_metadata0reduceproduction_id_optional_20_production_id,metadata0prods_metadata0null,metadata0semicolon_metadata0reducedecl_productions,metadata0pipe_metadata0reducevarlist_empty,metadata0prod_metadata0reduceprods_rec,metadata0prod_metadata0reduceprods_element,metadata0type_metadata0reducetype_optional_18_type,metadata0decl_metadata0reducedecls_rec,metadata0production_lhs_metadata0reducestart_def,metadata0start_non_terminals_metadata0reducestart_non_terminals_optional_9_start_non_terminals,metadata0types_lhs_metadata0reducetypes_lhs_optional_8_types_lhs,metadata0versions_metadata0reduceversions_optional_7_versions,metadata0branch_lhs_metadata0reducebranch_lhs_optional_5_branch_lhs,metadata0comment_lhs_metadata0reducecomment_lhs_optional_4_comment_lhs};
  }

  
  private int[] prodsGotoes;

  private void initprodsGotoes() {
    prodsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,177,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] terminal_or_prod_priorityGotoes;

  private void initterminal_or_prod_priorityGotoes() {
    terminal_or_prod_priorityGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,52,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,91,-1,-1,-1,95,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,165,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] types_lhs_optional_8Gotoes;

  private void inittypes_lhs_optional_8Gotoes() {
    types_lhs_optional_8Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,124,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] lexemGotoes;

  private void initlexemGotoes() {
    lexemGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,59,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] error_lhs_optional_6Gotoes;

  private void initerror_lhs_optional_6Gotoes() {
    error_lhs_optional_6Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,103,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] import_Gotoes;

  private void initimport_Gotoes() {
    import_Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,14,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] regexGotoes;

  private void initregexGotoes() {
    regexGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,46,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,58,-1,-1,-1,-1,-1,-1,-1,66,-1,-1,-1,70,-1,-1,-1,-1,-1,-1,-1,-1,79,-1,-1,-1,83,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] version_listGotoes;

  private void initversion_listGotoes() {
    version_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,106,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] variableGotoes;

  private void initvariableGotoes() {
    variableGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,122,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] type_optional_18Gotoes;

  private void inittype_optional_18Gotoes() {
    type_optional_18Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,136,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] comments_listGotoes;

  private void initcomments_listGotoes() {
    comments_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,76,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] declGotoes;

  private void initdeclGotoes() {
    declGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,183,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] terminal_or_prod_priority_optional_14Gotoes;

  private void initterminal_or_prod_priority_optional_14Gotoes() {
    terminal_or_prod_priority_optional_14Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,53,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] qmark_optional_23Gotoes;

  private void initqmark_optional_23Gotoes() {
    qmark_optional_23Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,151,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] priorities_lhs_optional_2Gotoes;

  private void initpriorities_lhs_optional_2Gotoes() {
    priorities_lhs_optional_2Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,26,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] start_non_terminalsGotoes;

  private void initstart_non_terminalsGotoes() {
    start_non_terminalsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,185,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] varlistGotoes;

  private void initvarlistGotoes() {
    varlistGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,138,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,138,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] comment_lhs_optional_4Gotoes;

  private void initcomment_lhs_optional_4Gotoes() {
    comment_lhs_optional_4Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,85,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] separator_optional_26Gotoes;

  private void initseparator_optional_26Gotoes() {
    separator_optional_26Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,149,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] branch_lexemGotoes;

  private void initbranch_lexemGotoes() {
    branch_lexemGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,97,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] priorities_lhsGotoes;

  private void initpriorities_lhsGotoes() {
    priorities_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,25,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] blank_lhs_optional_3Gotoes;

  private void initblank_lhs_optional_3Gotoes() {
    blank_lhs_optional_3Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,73,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] banches_listGotoes;

  private void initbanches_listGotoes() {
    banches_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,88,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] production_version_optional_21Gotoes;

  private void initproduction_version_optional_21Gotoes() {
    production_version_optional_21Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,173,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] parent_version_optional_10Gotoes;

  private void initparent_version_optional_10Gotoes() {
    parent_version_optional_10Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,110,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] comment_lexemGotoes;

  private void initcomment_lexemGotoes() {
    comment_lexemGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,84,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] terminal_or_prod_priority_optional_16Gotoes;

  private void initterminal_or_prod_priority_optional_16Gotoes() {
    terminal_or_prod_priority_optional_16Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,92,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] vartypedefGotoes;

  private void initvartypedefGotoes() {
    vartypedefGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,121,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] directives_lhsGotoes;

  private void initdirectives_lhsGotoes() {
    directives_lhsGotoes = 
      new int[]{6,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] directives_lhs_optional_0Gotoes;

  private void initdirectives_lhs_optional_0Gotoes() {
    directives_lhs_optional_0Gotoes = 
      new int[]{9,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] vargroupGotoes;

  private void initvargroupGotoes() {
    vargroupGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,162,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] comment_lhsGotoes;

  private void initcomment_lhsGotoes() {
    comment_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,189,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] versions_optional_7Gotoes;

  private void initversions_optional_7Gotoes() {
    versions_optional_7Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,113,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] aliasGotoes;

  private void initaliasGotoes() {
    aliasGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,34,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] blank_lexemGotoes;

  private void initblank_lexemGotoes() {
    blank_lexemGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,71,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] terminal_or_prod_priority_optional_17Gotoes;

  private void initterminal_or_prod_priority_optional_17Gotoes() {
    terminal_or_prod_priority_optional_17Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,96,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] regex_terminal_decl_optional_13Gotoes;

  private void initregex_terminal_decl_optional_13Gotoes() {
    regex_terminal_decl_optional_13Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,48,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] startidGotoes;

  private void initstartidGotoes() {
    startidGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,130,-1,129,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] production_lhsGotoes;

  private void initproduction_lhsGotoes() {
    production_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,184,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] separator_optional_25Gotoes;

  private void initseparator_optional_25Gotoes() {
    separator_optional_25Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,154,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] error_lhsGotoes;

  private void initerror_lhsGotoes() {
    error_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,102,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] vartypedef_listGotoes;

  private void initvartypedef_listGotoes() {
    vartypedef_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,116,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] blank_lhsGotoes;

  private void initblank_lhsGotoes() {
    blank_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,72,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] branch_lhs_optional_5Gotoes;

  private void initbranch_lhs_optional_5Gotoes() {
    branch_lhs_optional_5Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,98,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] declsGotoes;

  private void initdeclsGotoes() {
    declsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,134,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] regex_terminal_declGotoes;

  private void initregex_terminal_declGotoes() {
    regex_terminal_declGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,47,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] imports_lhs_optional_1Gotoes;

  private void initimports_lhs_optional_1Gotoes() {
    imports_lhs_optional_1Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,16,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] type_optional_15Gotoes;

  private void inittype_optional_15Gotoes() {
    type_optional_15Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,90,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] varGotoes;

  private void initvarGotoes() {
    varGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,166,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,161,-1,164,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] production_idGotoes;

  private void initproduction_idGotoes() {
    production_idGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,176,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] typeGotoes;

  private void inittypeGotoes() {
    typeGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,54,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,93,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,123,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,182,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] blanks_listGotoes;

  private void initblanks_listGotoes() {
    blanks_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,63,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] type_optional_12Gotoes;

  private void inittype_optional_12Gotoes() {
    type_optional_12Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,38,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] priority_listGotoes;

  private void initpriority_listGotoes() {
    priority_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,19,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] directiveGotoes;

  private void initdirectiveGotoes() {
    directiveGotoes = 
      new int[]{-1,-1,-1,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] production_versionGotoes;

  private void initproduction_versionGotoes() {
    production_versionGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,172,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] branch_lhsGotoes;

  private void initbranch_lhsGotoes() {
    branch_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,188,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] start_non_terminals_optional_9Gotoes;

  private void initstart_non_terminals_optional_9Gotoes() {
    start_non_terminals_optional_9Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,131,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] alias_optional_11Gotoes;

  private void initalias_optional_11Gotoes() {
    alias_optional_11Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,35,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] types_lhsGotoes;

  private void inittypes_lhsGotoes() {
    types_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,186,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] separator_optional_27Gotoes;

  private void initseparator_optional_27Gotoes() {
    separator_optional_27Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,146,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] qmark_optional_22Gotoes;

  private void initqmark_optional_22Gotoes() {
    qmark_optional_22Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,156,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] separatorGotoes;

  private void initseparatorGotoes() {
    separatorGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,148,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,157,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] starts_listGotoes;

  private void initstarts_listGotoes() {
    starts_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,128,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] tokens_listGotoes;

  private void inittokens_listGotoes() {
    tokens_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,29,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] versionsGotoes;

  private void initversionsGotoes() {
    versionsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,187,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] startGotoes;

  private void initstartGotoes() {
    startGotoes = 
      new int[]{7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] prodGotoes;

  private void initprodGotoes() {
    prodGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,181,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,180,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] parent_versionGotoes;

  private void initparent_versionGotoes() {
    parent_versionGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,111,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] terminal_or_prod_priority_optional_19Gotoes;

  private void initterminal_or_prod_priority_optional_19Gotoes() {
    terminal_or_prod_priority_optional_19Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,167,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] versionGotoes;

  private void initversionGotoes() {
    versionGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,112,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] priorityGotoes;

  private void initpriorityGotoes() {
    priorityGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,24,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] token_lhsGotoes;

  private void inittoken_lhsGotoes() {
    token_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,60,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] import_listGotoes;

  private void initimport_listGotoes() {
    import_listGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,12,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] imports_lhsGotoes;

  private void initimports_lhsGotoes() {
    imports_lhsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,15,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] directive_listGotoes;

  private void initdirective_listGotoes() {
    directive_listGotoes = 
      new int[]{-1,-1,3,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] separator_optional_24Gotoes;

  private void initseparator_optional_24Gotoes() {
    separator_optional_24Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,158,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] production_id_optional_20Gotoes;

  private void initproduction_id_optional_20Gotoes() {
    production_id_optional_20Gotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,175,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] idArray;
  @SuppressWarnings("unchecked")
  private void initidArray() {
    idArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,reducedirective_list_empty,shift4,reducedirective_def,reducedirective_list_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducepriority_list_empty,shift20,branch0,branch0,branch0,reducepriority_def,reducepriority_list_rec,branch0,branch0,branch0,reducetokens_list_empty,shift30,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,shift50,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,shift56,branch0,branch0,reducelexem_macro,reducetokens_list_rec,branch0,branch0,reduceblanks_list_empty,shift64,branch0,branch0,reduceblank_lexem_terminal,shift68,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,branch0,branch0,branch0,reducecomments_list_empty,shift77,branch0,branch0,reducecomment_lexem_terminal,shift81,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,branch0,branch0,reducebanches_list_empty,shift89,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,branch0,branch0,shift101,branch0,branch0,branch0,branch0,reduceversion_list_empty,shift107,reduceparent_version_optional_10_empty,shift109,reduceparent_version_def,reduceversion_def,reduceparent_version_optional_10_parent_version,reduceversion_list_rec,branch0,branch0,reducevartypedef_list_empty,shift117,branch0,shift119,branch0,branch0,reducevartypedef_list_rec,branch0,reducevartype_def,branch0,branch0,shift127,reducestartid_def,shift127,reducestarts_list_rec,reducestarts_list_element,branch0,branch0,reducedecls_empty,shift135,branch0,branch0,reducevarlist_empty,shift139,reduceqmark_optional_23_empty,shift141,branch0,shift143,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,shift139,reducevargroup_element,shift139,reducevar_group,reducevargroup_rec,branch0,reducevarlist_rec,branch0,shift169,branch0,shift171,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducedecl_productions,reducevarlist_empty,branch0,branch0,branch0,reducedecls_rec,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] tokensdeclArray;
  @SuppressWarnings("unchecked")
  private void inittokensdeclArray() {
    tokensdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional_0_empty,branch0,reducedirective_list_empty,reducedirectives_def,reducedirective_def,reducedirective_list_rec,reducedirectives_lhs_optional_0_directives_lhs,branch0,branch0,reduceimports_lhs_optional_1_empty,branch0,reduceimport_list_empty,reduceimports_def,reduceimport_def,reduceimport_list_rec,reduceimports_lhs_optional_1_imports_lhs,reducepriorities_lhs_optional_2_empty,branch0,reducepriority_list_empty,reducepriorities_def,branch0,branch0,branch0,reducepriority_def,reducepriority_list_rec,reducepriorities_lhs_optional_2_priorities_lhs,shift27,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] qmarkArray;
  @SuppressWarnings("unchecked")
  private void initqmarkArray() {
    qmarkArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift145,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift153,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] typesdeclArray;
  @SuppressWarnings("unchecked")
  private void inittypesdeclArray() {
    typesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,reducebranch_lhs_optional_5_empty,branch0,reducebanches_list_empty,reducebranch_def,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,reduceerror_lhs_optional_6_empty,branch0,branch0,reduceerror_def,reduceerror_lhs_optional_6_error_lhs,reduceversions_optional_7_empty,branch0,reduceversion_list_empty,reduceversions_def,reduceparent_version_optional_10_empty,branch0,reduceparent_version_def,reduceversion_def,reduceparent_version_optional_10_parent_version,reduceversion_list_rec,shift114,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceversions_optional_7_versions,reducebranch_lhs_optional_5_branch_lhs,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] errordeclArray;
  @SuppressWarnings("unchecked")
  private void initerrordeclArray() {
    errordeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,reducebranch_lhs_optional_5_empty,branch0,reducebanches_list_empty,reducebranch_def,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,shift99,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducebranch_lhs_optional_5_branch_lhs,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] versionsdeclArray;
  @SuppressWarnings("unchecked")
  private void initversionsdeclArray() {
    versionsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,reducebranch_lhs_optional_5_empty,branch0,reducebanches_list_empty,reducebranch_def,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,reduceerror_lhs_optional_6_empty,branch0,branch0,reduceerror_def,reduceerror_lhs_optional_6_error_lhs,shift104,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducebranch_lhs_optional_5_branch_lhs,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] importsdeclArray;
  @SuppressWarnings("unchecked")
  private void initimportsdeclArray() {
    importsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional_0_empty,branch0,reducedirective_list_empty,reducedirectives_def,reducedirective_def,reducedirective_list_rec,reducedirectives_lhs_optional_0_directives_lhs,branch0,branch0,shift10,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] startsdeclArray;
  @SuppressWarnings("unchecked")
  private void initstartsdeclArray() {
    startsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,reducebranch_lhs_optional_5_empty,branch0,reducebanches_list_empty,reducebranch_def,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,reduceerror_lhs_optional_6_empty,branch0,branch0,reduceerror_def,reduceerror_lhs_optional_6_error_lhs,reduceversions_optional_7_empty,branch0,reduceversion_list_empty,reduceversions_def,reduceparent_version_optional_10_empty,branch0,reduceparent_version_def,reduceversion_def,reduceparent_version_optional_10_parent_version,reduceversion_list_rec,reducetypes_lhs_optional_8_empty,branch0,reducevartypedef_list_empty,reducetypes_def,branch0,branch0,branch0,branch0,reducevartypedef_list_rec,branch0,reducevartype_def,shift125,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetypes_lhs_optional_8_types_lhs,reduceversions_optional_7_versions,reducebranch_lhs_optional_5_branch_lhs,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] numberArray;
  @SuppressWarnings("unchecked")
  private void initnumberArray() {
    numberArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift22,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] qualifiedidArray;
  @SuppressWarnings("unchecked")
  private void initqualifiedidArray() {
    qualifiedidArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceimport_list_empty,shift13,reduceimport_def,reduceimport_list_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift37,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbracketArray;
  @SuppressWarnings("unchecked")
  private void initrbracketArray() {
    rbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceproduction_version_optional_21_empty,branch0,reduceproduction_version,reduceproduction_version_optional_21_production_version,shift174,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lsqbracketArray;
  @SuppressWarnings("unchecked")
  private void initlsqbracketArray() {
    lsqbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,shift49,branch0,branch0,branch0,branch0,branch0,reducetype_optional_12_type,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_optional_15_empty,shift49,branch0,branch0,reducetype_optional_15_type,shift49,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,shift49,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,branch0,branch0,branch0,reducevar_group,branch0,branch0,reducevarlist_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] semicolonArray;
  @SuppressWarnings("unchecked")
  private void initsemicolonArray() {
    semicolonArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceterminal_or_prod_priority,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,reduceterminal_or_prod_priority_optional_19_empty,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,branch0,branch0,branch0,reducevar_group,branch0,reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority,reducevarlist_rec,reduceproduction_id_optional_20_empty,branch0,branch0,branch0,branch0,branch0,branch0,reduceproduction_id,reduceprod_production,reduceproduction_id_optional_20_production_id,shift178,branch0,reducevarlist_empty,reduceprods_rec,reduceprods_element,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rsqbracketArray;
  @SuppressWarnings("unchecked")
  private void initrsqbracketArray() {
    rsqbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift51,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] plusArray;
  @SuppressWarnings("unchecked")
  private void initplusArray() {
    plusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceseparator_optional_27_empty,branch0,reduceseparator_non_terminal,branch0,branch0,reduceseparator_terminal,branch0,shift147,branch0,reduceseparator_optional_27_separator,branch0,branch0,branch0,reduceseparator_optional_25_empty,branch0,shift155,branch0,branch0,reduceseparator_optional_25_separator,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchesdeclArray;
  @SuppressWarnings("unchecked")
  private void initbranchesdeclArray() {
    branchesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,shift86,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] colonArray;
  @SuppressWarnings("unchecked")
  private void initcolonArray() {
    colonArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,shift2,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift11,branch0,branch0,branch0,branch0,branch0,branch0,shift18,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift28,branch0,branch0,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,shift36,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift62,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift75,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift87,branch0,branch0,shift36,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift100,branch0,branch0,branch0,branch0,shift105,branch0,branch0,shift108,branch0,branch0,branch0,branch0,branch0,branch0,shift115,branch0,branch0,reducevariable_nonterminal,branch0,branch0,reducevariable_terminal,branch0,shift36,branch0,branch0,shift126,branch0,branch0,branch0,branch0,branch0,branch0,shift133,branch0,branch0,shift36,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift170,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoteArray;
  @SuppressWarnings("unchecked")
  private void initquoteArray() {
    quoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_def,branch0,shift43,branch0,branch0,branch0,branch0,shift45,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift43,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift43,branch0,branch0,branch0,shift43,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift43,branch0,branch0,branch0,shift43,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevartypedef_list_empty,shift118,branch0,branch0,shift120,branch0,reducevartypedef_list_rec,branch0,reducevartype_def,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift142,branch0,branch0,shift144,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] prioritiesdeclArray;
  @SuppressWarnings("unchecked")
  private void initprioritiesdeclArray() {
    prioritiesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{reducedirectives_lhs_optional_0_empty,branch0,reducedirective_list_empty,reducedirectives_def,reducedirective_def,reducedirective_list_rec,reducedirectives_lhs_optional_0_directives_lhs,branch0,branch0,reduceimports_lhs_optional_1_empty,branch0,reduceimport_list_empty,reduceimports_def,reduceimport_def,reduceimport_list_rec,reduceimports_lhs_optional_1_imports_lhs,shift17,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] starArray;
  @SuppressWarnings("unchecked")
  private void initstarArray() {
    starArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceseparator_optional_26_empty,branch0,reduceseparator_non_terminal,branch0,branch0,reduceseparator_terminal,branch0,branch0,branch0,reduceseparator_optional_26_separator,shift150,branch0,branch0,reduceseparator_optional_24_empty,branch0,branch0,branch0,branch0,reduceseparator_optional_24_separator,shift159,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbracketArray;
  @SuppressWarnings("unchecked")
  private void initlbracketArray() {
    lbracketArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceterminal_or_prod_priority,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,reduceterminal_or_prod_priority_optional_19_empty,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,branch0,branch0,branch0,reducevar_group,branch0,reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority,reducevarlist_rec,shift168,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] assocArray;
  @SuppressWarnings("unchecked")
  private void initassocArray() {
    assocArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift23,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] directivesdeclArray;
  @SuppressWarnings("unchecked")
  private void initdirectivesdeclArray() {
    directivesdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift1,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] slashArray;
  @SuppressWarnings("unchecked")
  private void initslashArray() {
    slashArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift140,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift140,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] regexdoublequoteArray;
  @SuppressWarnings("unchecked")
  private void initregexdoublequoteArray() {
    regexdoublequoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift41,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rparArray;
  @SuppressWarnings("unchecked")
  private void initrparArray() {
    rparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift33,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,branch0,reducevargroup_element,shift163,reducevar_group,reducevargroup_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] eofArray;
  @SuppressWarnings("unchecked")
  private void initeofArray() {
    eofArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_def,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceterminal_or_prod_priority,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducebanches_list_empty,shift94,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lparArray;
  @SuppressWarnings("unchecked")
  private void initlparArray() {
    lparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift31,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,shift160,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,shift160,reducevargroup_element,shift160,reducevar_group,reducevargroup_rec,branch0,reducevarlist_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] pipeArray;
  @SuppressWarnings("unchecked")
  private void initpipeArray() {
    pipeArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceterminal_or_prod_priority,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,reduceterminal_or_prod_priority_optional_19_empty,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,branch0,branch0,branch0,reducevar_group,branch0,reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority,reducevarlist_rec,reduceproduction_id_optional_20_empty,branch0,branch0,branch0,branch0,branch0,branch0,reduceproduction_id,reduceprod_production,reduceproduction_id_optional_20_production_id,shift179,branch0,reducevarlist_empty,reduceprods_rec,reduceprods_element,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoted_nameArray;
  @SuppressWarnings("unchecked")
  private void initquoted_nameArray() {
    quoted_nameArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift32,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,shift152,reduceqmark_optional_23_empty,branch0,branch0,branch0,branch0,branch0,reduceqmark_optional_23_qmark,branch0,reducevar_nonterminal_plus,branch0,branch0,reducevar_nonterminal_star,reducevar_nonterminal,reduceqmark_optional_22_empty,reduceqmark_optional_22_qmark,branch0,reducevar_terminal_plus,reducevar_terminal,branch0,branch0,reducevar_terminal_star,shift152,reducevargroup_element,shift152,reducevar_group,reducevargroup_rec,branch0,reducevarlist_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducevarlist_empty,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dollarArray;
  @SuppressWarnings("unchecked")
  private void initdollarArray() {
    dollarArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,shift55,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,branch0,branch0,reduceblanks_list_empty,shift67,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,branch0,branch0,branch0,reducecomments_list_empty,shift80,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] commentsdeclArray;
  @SuppressWarnings("unchecked")
  private void initcommentsdeclArray() {
    commentsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,shift74,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] __eof__Array;
  @SuppressWarnings("unchecked")
  private void init__eof__Array() {
    __eof__Array=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,accept,accept,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducedecls_empty,reduceproduction_def,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducedecl_productions,branch0,branch0,branch0,branch0,reducedecls_rec,reducestart_def,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] doublequoteArray;
  @SuppressWarnings("unchecked")
  private void initdoublequoteArray() {
    doublequoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift40,branch0,shift42,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift40,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift40,branch0,branch0,branch0,shift40,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift40,branch0,branch0,branch0,shift40,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] assignArray;
  @SuppressWarnings("unchecked")
  private void initassignArray() {
    assignArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift21,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,shift39,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_optional_12_type,branch0,shift57,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift65,branch0,branch0,branch0,shift69,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift78,branch0,branch0,branch0,shift82,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_optional_18_empty,shift137,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetype_optional_18_type,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] productionsdeclArray;
  @SuppressWarnings("unchecked")
  private void initproductionsdeclArray() {
    productionsdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,reduceblank_lhs_optional_3_empty,branch0,reduceblanks_list_empty,reduceblank_def,branch0,branch0,reduceblank_lexem_terminal,branch0,branch0,branch0,reduceblank_lexem_macro,reduceblanks_list_rec,reduceblank_lhs_optional_3_blank_lhs,reducecomment_lhs_optional_4_empty,branch0,reducecomments_list_empty,reducecomment_def,branch0,branch0,reducecomment_lexem_terminal,branch0,branch0,branch0,reducecomment_lexem_macro,reducecomments_list_rec,reducebranch_lhs_optional_5_empty,branch0,reducebanches_list_empty,reducebranch_def,reducetype_optional_15_empty,reduceterminal_or_prod_priority_optional_16_empty,reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority,reducebranch_lexem_terminal,reducetype_optional_15_type,reduceterminal_or_prod_priority_optional_17_empty,reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority,reducebranch_eof_terminal,reducebanches_list_rec,reduceerror_lhs_optional_6_empty,branch0,branch0,reduceerror_def,reduceerror_lhs_optional_6_error_lhs,reduceversions_optional_7_empty,branch0,reduceversion_list_empty,reduceversions_def,reduceparent_version_optional_10_empty,branch0,reduceparent_version_def,reduceversion_def,reduceparent_version_optional_10_parent_version,reduceversion_list_rec,reducetypes_lhs_optional_8_empty,branch0,reducevartypedef_list_empty,reducetypes_def,branch0,branch0,branch0,branch0,reducevartypedef_list_rec,branch0,reducevartype_def,reducestart_non_terminals_optional_9_empty,branch0,branch0,reducestartid_def,reducestart_non_terminals_def,reducestarts_list_rec,reducestarts_list_element,shift132,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducestart_non_terminals_optional_9_start_non_terminals,reducetypes_lhs_optional_8_types_lhs,reduceversions_optional_7_versions,reducebranch_lhs_optional_5_branch_lhs,reducecomment_lhs_optional_4_comment_lhs};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] blanksdeclArray;
  @SuppressWarnings("unchecked")
  private void initblanksdeclArray() {
    blanksdeclArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reducetokens_list_empty,reducetoken_def,reducealias_optional_11_empty,branch0,branch0,reducealias_def,reducealias_optional_11_alias,reducetype_optional_12_empty,branch0,reducetype_def,reduceregex_terminal_decl_optional_13_empty,branch0,branch0,branch0,reduceregex_doublequote,branch0,branch0,reduceregex_quote,reduceregex_terminal_decl,reduceregex_terminal_decl_optional_13_regex_terminal_decl,reduceterminal_or_prod_priority_optional_14_empty,branch0,branch0,reduceterminal_or_prod_priority,reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority,reducelexem_terminal,reducetype_optional_12_type,branch0,branch0,branch0,reducelexem_macro,reducetokens_list_rec,shift61,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] regexquoteArray;
  @SuppressWarnings("unchecked")
  private void initregexquoteArray() {
    regexquoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift44,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchArrayTable;
  @SuppressWarnings("unchecked")
  private void initBranchArrayTable() {
    branchArrayTable=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{error0,error0,error0,error0,error0,error0,error0,exit,exit,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,reducedecls_empty,reduceproduction_def,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,reducedecl_productions,error0,error0,error0,error0,reducedecls_rec,reducestart_def,error0,error0,error0,error0,error0};
  }

  private final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> table;
  
  public static final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> createTable() {
    return new ParserDataTable().table;
  }

  private final AcceptAction<TerminalEnum,ProductionEnum,VersionEnum> accept;
  private final ExitAction<TerminalEnum,ProductionEnum,VersionEnum> exit;

  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_24_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_lhs_optional_1_imports_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_19_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetoken_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_12_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id_optional_20_production_id;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_optional_10_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_19_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_eof_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_optional_11_alias;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprods_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_optional_7_versions;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal_star;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestartid_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_optional_11_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblanks_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartypedef_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestarts_list_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_25_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetokens_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomments_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_lhs_optional_0_directives_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_27_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lexem_macro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevariable_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversions_optional_7_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_lhs_optional_6_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomment_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_26_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_16_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartypedef_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional_22_qmark;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_quote;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_lhs_optional_2_priorities_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional_22_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_non_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblanks_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_lhs_optional_0_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_17_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomment_lexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_15_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_26_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lhs_optional_3_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetokens_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomment_lhs_optional_4_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducealias_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_lhs_optional_8_types_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_doublequote;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_optional_9_start_non_terminals;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevariable_nonterminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevartype_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomment_lexem_macro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebanches_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestarts_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version_optional_21_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id_optional_20_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_18_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevarlist_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetypes_lhs_optional_8_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_lhs_optional_3_blank_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomment_lhs_optional_4_comment_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_version_optional_21_production_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_27_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducecomments_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_group;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriority_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_lhs_optional_1_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducelexem_macro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprods_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_14_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_17_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_14_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceversion_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_12_type;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceerror_lhs_optional_6_error_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducepriorities_lhs_optional_2_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecls_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl_optional_13_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirective_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestart_non_terminals_optional_9_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecl_productions;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal_star;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedirectives_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevargroup_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceblank_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_15_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lhs_optional_5_branch_lhs;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevarlist_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducelexem_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional_23_qmark;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_24_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceprod_production;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregex_terminal_decl_optional_13_regex_terminal_decl;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducedecls_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_nonterminal_plus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceseparator_optional_25_separator;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_id;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceterminal_or_prod_priority_optional_16_terminal_or_prod_priority;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimports_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_list_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceparent_version_optional_10_parent_version;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal_plus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceproduction_def;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducetype_optional_18_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebanches_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceimport_list_rec;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceqmark_optional_23_empty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevargroup_element;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducevar_terminal;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducebranch_lhs_optional_5_empty;

  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift23;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift39;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift64;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift101;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift159;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift49;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift139;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift31;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift171;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift142;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift117;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift78;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift61;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift104;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift132;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift155;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift174;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift4;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift65;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift82;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift127;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift147;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift1;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift13;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift118;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift17;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift126;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift30;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift56;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift163;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift153;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift120;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift50;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift144;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift114;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift150;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift107;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift108;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift140;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift74;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift20;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift27;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift89;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift75;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift22;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift135;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift33;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift133;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift42;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift160;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift67;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift32;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift44;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift55;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift81;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift41;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift68;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift141;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift152;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift100;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift125;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift115;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift57;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift179;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift18;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift86;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift10;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift168;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift11;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift145;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift109;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift80;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift169;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift143;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift43;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift62;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift105;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift51;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift45;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift21;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift28;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift87;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift36;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift94;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift77;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift2;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift178;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift69;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift170;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift119;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift99;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift37;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift40;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift137;


  private final ErrorAction<TerminalEnum,ProductionEnum,VersionEnum> error0;

  private final BranchAction<TerminalEnum,ProductionEnum,VersionEnum> branch0;

}
