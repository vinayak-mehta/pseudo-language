package fr.umlv.tatoo.cc.parser.parser;

public class NonAssociativeErrorActionDecl extends ErrorActionDecl implements RegularTableActionDecl {
  NonAssociativeErrorActionDecl(String name,String message) {
    super(name,message);
  }
}