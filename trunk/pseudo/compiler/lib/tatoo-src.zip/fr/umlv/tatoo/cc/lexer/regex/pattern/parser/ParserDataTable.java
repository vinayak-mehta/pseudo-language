package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.TerminalEnum;
import fr.umlv.tatoo.runtime.parser.AcceptAction;
import fr.umlv.tatoo.runtime.parser.Action;
import fr.umlv.tatoo.runtime.parser.BranchAction;
import fr.umlv.tatoo.runtime.parser.ErrorAction;
import fr.umlv.tatoo.runtime.parser.ExitAction;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.parser.ReduceAction;
import fr.umlv.tatoo.runtime.parser.ShiftAction;
import fr.umlv.tatoo.runtime.parser.StateMetadata;
import java.util.EnumMap;

/** 
 *  This class is generated - please do not edit it 
 */
public class ParserDataTable {
  private ParserDataTable() {
   accept = AcceptAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
   exit = ExitAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    initintervalGotoes();
    initspecialOrStringLetterGotoes();
    initmacroGotoes();
    initmainGotoes();
    initspecialOrNormalLetterGotoes();
    inithatOptGotoes();
    initstringGotoes();
    initregexGotoes();
    initpatternGotoes();
    initfollowGotoes();
    initspecialOrIntervalLetterGotoes();
    initintervalsGotoes();
    reduceregexAtLeast = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAtLeast,5,regexGotoes);
    reduceregexAny = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAny,1,regexGotoes);
    reduceinitial = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.initial,3,patternGotoes);
    reduceregexString = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexString,3,regexGotoes);
    reducemainRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.mainRegex,1,mainGotoes);
    reduceregexIntervalNegate = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexIntervalNegate,4,regexGotoes);
    reduceregexStar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexStar,2,regexGotoes);
    reducehatPresent = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatPresent,1,hatOptGotoes);
    reducenormalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalSpecialLetter,1,specialOrNormalLetterGotoes);
    reduceregexCat = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexCat,2,regexGotoes);
    reduceintervalSet = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSet,3,intervalGotoes);
    reducestringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringLetter,1,specialOrStringLetterGotoes);
    reduceregexPar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPar,3,regexGotoes);
    reduceregexRange = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexRange,6,regexGotoes);
    reduceregexMacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexMacro,1,regexGotoes);
    reduceintervals = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervals,2,intervalsGotoes);
    reducefollowRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followRegex,2,followGotoes);
    reducemacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.macro,1,macroGotoes);
    reduceregexOr = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOr,3,regexGotoes);
    reduceregexOptional = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOptional,2,regexGotoes);
    reduceregexTimes = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexTimes,4,regexGotoes);
    reduceregexLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexLetter,1,regexGotoes);
    reduceintervalSingleton = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSingleton,1,intervalGotoes);
    reducehatEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatEmpty,0,hatOptGotoes);
    reduceintervalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalLetter,1,specialOrIntervalLetterGotoes);
    reduceregexInterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexInterval,3,regexGotoes);
    reducefollowDollar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followDollar,1,followGotoes);
    reducestringSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringSpecialLetter,1,specialOrStringLetterGotoes);
    reduceinterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.interval,1,intervalsGotoes);
    reducefollowEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followEmpty,0,followGotoes);
    reducespecialOrStringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.specialOrStringLetter,1,stringGotoes);
    reduceregexPlus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPlus,2,regexGotoes);
    reduceintervalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSpecialLetter,1,specialOrIntervalLetterGotoes);
    reducenormalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalLetter,1,specialOrNormalLetterGotoes);
    reducestring = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.string,2,stringGotoes);
    shift4 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(4);
    shift3 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(3);
    shift1 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(1);
    shift34 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(34);
    shift31 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(31);
    shift32 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(32);
    shift20 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(20);
    shift18 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(18);
    shift38 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(38);
    shift8 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(8);
    shift49 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(49);
    shift11 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(11);
    shift6 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(6);
    shift2 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(2);
    shift28 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(28);
    shift30 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(30);
    shift39 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(39);
    shift46 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(46);
    shift24 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(24);
    shift14 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(14);
    shift36 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(36);
    shift51 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(51);
    shift19 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(19);
    shift17 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(17);
    shift33 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(33);
    shift7 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(7);
    shift5 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(5);
    shift29 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(29);
    shift37 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(37);
    shift21 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(21);
    shift35 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(35);
    error0 = new ErrorAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    branch0 = new BranchAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    initrparArray();
    initplusArray();
    initstarArray();
    initlparArray();
    inithatArray();
    initintervalLetterArray();
    initlbrakArray();
    initrbrakArray();
    initdotArray();
    initstringLetterArray();
    initslashArray();
    initintegerArray();
    initrbracArray();
    initnormalLetterArray();
    initquestionArray();
    initlbracArray();
    initspecialLetterArray();
    initcommaArray();
    init__eof__Array();
    initnameArray();
    initpipeArray();
    initdollarArray();
    initquoteArray();
    initminusArray();
    EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]> tableMap =
      new EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]>(TerminalEnum.class);
      
    tableMap.put(TerminalEnum.rpar,rparArray);
    tableMap.put(TerminalEnum.plus,plusArray);
    tableMap.put(TerminalEnum.star,starArray);
    tableMap.put(TerminalEnum.lpar,lparArray);
    tableMap.put(TerminalEnum.hat,hatArray);
    tableMap.put(TerminalEnum.intervalLetter,intervalLetterArray);
    tableMap.put(TerminalEnum.lbrak,lbrakArray);
    tableMap.put(TerminalEnum.rbrak,rbrakArray);
    tableMap.put(TerminalEnum.dot,dotArray);
    tableMap.put(TerminalEnum.stringLetter,stringLetterArray);
    tableMap.put(TerminalEnum.slash,slashArray);
    tableMap.put(TerminalEnum.integer,integerArray);
    tableMap.put(TerminalEnum.rbrac,rbracArray);
    tableMap.put(TerminalEnum.normalLetter,normalLetterArray);
    tableMap.put(TerminalEnum.question,questionArray);
    tableMap.put(TerminalEnum.lbrac,lbracArray);
    tableMap.put(TerminalEnum.specialLetter,specialLetterArray);
    tableMap.put(TerminalEnum.comma,commaArray);
    tableMap.put(TerminalEnum.__eof__,__eof__Array);
    tableMap.put(TerminalEnum.name,nameArray);
    tableMap.put(TerminalEnum.pipe,pipeArray);
    tableMap.put(TerminalEnum.dollar,dollarArray);
    tableMap.put(TerminalEnum.quote,quoteArray);
    tableMap.put(TerminalEnum.minus,minusArray);
    initBranchArrayTable();
    
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] tableMetadata = createStateMetadataTable();
    
    EnumMap<NonTerminalEnum,Integer> tableStarts =
      new EnumMap<NonTerminalEnum,Integer>(NonTerminalEnum.class);
    tableStarts.put(NonTerminalEnum.macro,0);
    tableStarts.put(NonTerminalEnum.pattern,45);
    table = new ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>(tableMap,branchArrayTable,tableMetadata,tableStarts,VersionEnum.values(),56,TerminalEnum.__eof__,null);
  } 

  @SuppressWarnings("unchecked")
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] createStateMetadataTable() {
         
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrak_metadata0reduceregexInterval = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrak,reduceregexInterval);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0name_metadata0reduceregexMacro = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.name,reduceregexMacro);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lpar_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lpar,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrak_metadata0reduceregexIntervalNegate = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrak,reduceregexIntervalNegate);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0slash_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.slash,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0question_metadata0reduceregexOptional = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.question,reduceregexOptional);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0null_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(null,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0reduceregexString = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,reduceregexString);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lbrak_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrak,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrIntervalLetter_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrIntervalLetter,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0pipe_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.pipe,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comma_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.comma,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rpar_metadata0reduceregexPar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar,reduceregexPar);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexAtLeast = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexAtLeast);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexTimes = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexTimes);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0stringLetter_metadata0reducestringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.stringLetter,reducestringLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0follow_metadata0reduceinitial = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.follow,reduceinitial);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lbrac_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrac,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0plus_metadata0reduceregexPlus = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus,reduceregexPlus);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reducenormalSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reducenormalSpecialLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0star_metadata0reduceregexStar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star,reduceregexStar);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0dot_metadata0reduceregexAny = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dot,reduceregexAny);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrStringLetter_metadata0reducespecialOrStringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrStringLetter,reducespecialOrStringLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0dollar_metadata0reducefollowDollar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dollar,reducefollowDollar);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0main_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.main,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hatOpt_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.hatOpt,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0integer_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.integer,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0interval_metadata0reduceintervals = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.interval,reduceintervals);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reduceintervalSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reduceintervalSpecialLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrStringLetter_metadata0reducestring = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrStringLetter,reducestring);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0intervals_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.intervals,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0intervalLetter_metadata0reduceintervalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.intervalLetter,reduceintervalLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0normalLetter_metadata0reducenormalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.normalLetter,reducenormalLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reducestringSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reducestringSpecialLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0interval_metadata0reduceinterval = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.interval,reduceinterval);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hat_metadata0reducehatPresent = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.hat,reducehatPresent);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrNormalLetter_metadata0reduceregexLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrNormalLetter,reduceregexLetter);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrIntervalLetter_metadata0reduceintervalSet = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrIntervalLetter,reduceintervalSet);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0pattern_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.pattern,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0__eof___metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.__eof__,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0minus_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.minus,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexRange = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexRange);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hat_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.hat,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0macro_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.macro,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0string_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.string,null);
     
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,null);

    return (StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[])new StateMetadata<?,?,?,?>[]{metadata0null_metadata0null,metadata0normalLetter_metadata0reducenormalLetter,metadata0lpar_metadata0null,metadata0specialLetter_metadata0reducenormalSpecialLetter,metadata0name_metadata0reduceregexMacro,metadata0lbrak_metadata0null,metadata0hat_metadata0null,metadata0specialLetter_metadata0reduceintervalSpecialLetter,metadata0intervalLetter_metadata0reduceintervalLetter,metadata0interval_metadata0reduceinterval,metadata0specialOrIntervalLetter_metadata0null,metadata0minus_metadata0null,metadata0specialOrIntervalLetter_metadata0reduceintervalSet,metadata0intervals_metadata0null,metadata0rbrak_metadata0reduceregexIntervalNegate,metadata0interval_metadata0reduceintervals,metadata0intervals_metadata0null,metadata0rbrak_metadata0reduceregexInterval,metadata0dot_metadata0reduceregexAny,metadata0quote_metadata0null,metadata0specialLetter_metadata0reducestringSpecialLetter,metadata0stringLetter_metadata0reducestringLetter,metadata0specialOrStringLetter_metadata0reducespecialOrStringLetter,metadata0string_metadata0null,metadata0quote_metadata0reduceregexString,metadata0specialOrStringLetter_metadata0reducestring,metadata0specialOrNormalLetter_metadata0reduceregexLetter,metadata0regex_metadata0null,metadata0star_metadata0reduceregexStar,metadata0plus_metadata0reduceregexPlus,metadata0rpar_metadata0reduceregexPar,metadata0question_metadata0reduceregexOptional,metadata0lbrac_metadata0null,metadata0integer_metadata0null,metadata0rbrac_metadata0reduceregexTimes,metadata0comma_metadata0null,metadata0integer_metadata0null,metadata0rbrac_metadata0reduceregexRange,metadata0rbrac_metadata0reduceregexAtLeast,metadata0pipe_metadata0null,metadata0regex_metadata0null,metadata0regex_metadata0null,metadata0macro_metadata0null,metadata0__eof___metadata0null,metadata0regex_metadata0null,metadata0null_metadata0null,metadata0hat_metadata0reducehatPresent,metadata0hatOpt_metadata0null,metadata0main_metadata0null,metadata0slash_metadata0null,metadata0regex_metadata0null,metadata0dollar_metadata0reducefollowDollar,metadata0follow_metadata0reduceinitial,metadata0regex_metadata0null,metadata0pattern_metadata0null,metadata0__eof___metadata0null};
  }

  
  private int[] intervalGotoes;

  private void initintervalGotoes() {
    intervalGotoes = 
      new int[]{-1,-1,-1,-1,-1,9,9,-1,-1,-1,-1,-1,-1,15,-1,-1,15,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] specialOrStringLetterGotoes;

  private void initspecialOrStringLetterGotoes() {
    specialOrStringLetterGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,22,-1,-1,-1,25,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] macroGotoes;

  private void initmacroGotoes() {
    macroGotoes = 
      new int[]{42,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] mainGotoes;

  private void initmainGotoes() {
    mainGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,48,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] specialOrNormalLetterGotoes;

  private void initspecialOrNormalLetterGotoes() {
    specialOrNormalLetterGotoes = 
      new int[]{26,-1,26,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,26,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,26,26,26,-1,-1,26,-1,-1,26,-1,26,26,-1,-1,26,-1,-1};
  }
  
  private int[] hatOptGotoes;

  private void inithatOptGotoes() {
    hatOptGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,47,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] stringGotoes;

  private void initstringGotoes() {
    stringGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,23,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] regexGotoes;

  private void initregexGotoes() {
    regexGotoes = 
      new int[]{44,-1,27,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,41,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,40,41,41,-1,-1,41,-1,-1,53,-1,50,41,-1,-1,41,-1,-1};
  }
  
  private int[] patternGotoes;

  private void initpatternGotoes() {
    patternGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,54,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] followGotoes;

  private void initfollowGotoes() {
    followGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,52,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] specialOrIntervalLetterGotoes;

  private void initspecialOrIntervalLetterGotoes() {
    specialOrIntervalLetterGotoes = 
      new int[]{-1,-1,-1,-1,-1,10,10,-1,-1,-1,-1,12,-1,10,-1,-1,10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] intervalsGotoes;

  private void initintervalsGotoes() {
    intervalsGotoes = 
      new int[]{-1,-1,-1,-1,-1,16,13,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rparArray;
  @SuppressWarnings("unchecked")
  private void initrparArray() {
    rparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift30,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,reduceregexOr,reduceregexCat,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] plusArray;
  @SuppressWarnings("unchecked")
  private void initplusArray() {
    plusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift29,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,shift29,shift29,branch0,branch0,shift29,branch0,branch0,branch0,branch0,branch0,shift29,branch0,branch0,shift29,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] starArray;
  @SuppressWarnings("unchecked")
  private void initstarArray() {
    starArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift28,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,shift28,shift28,branch0,branch0,shift28,branch0,branch0,branch0,branch0,branch0,shift28,branch0,branch0,shift28,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lparArray;
  @SuppressWarnings("unchecked")
  private void initlparArray() {
    lparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift2,reducenormalLetter,shift2,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift2,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift2,shift2,reduceregexCat,branch0,branch0,shift2,reducehatEmpty,reducehatPresent,shift2,branch0,shift2,shift2,branch0,branch0,shift2,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] hatArray;
  @SuppressWarnings("unchecked")
  private void inithatArray() {
    hatArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,shift6,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift46,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] intervalLetterArray;
  @SuppressWarnings("unchecked")
  private void initintervalLetterArray() {
    intervalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,shift8,shift8,reduceintervalSpecialLetter,reduceintervalLetter,reduceinterval,reduceintervalSingleton,shift8,reduceintervalSet,shift8,branch0,reduceintervals,shift8,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbrakArray;
  @SuppressWarnings("unchecked")
  private void initlbrakArray() {
    lbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift5,reducenormalLetter,shift5,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift5,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift5,shift5,reduceregexCat,branch0,branch0,shift5,reducehatEmpty,reducehatPresent,shift5,branch0,shift5,shift5,branch0,branch0,shift5,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbrakArray;
  @SuppressWarnings("unchecked")
  private void initrbrakArray() {
    rbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceintervalSpecialLetter,reduceintervalLetter,reduceinterval,reduceintervalSingleton,branch0,reduceintervalSet,shift14,branch0,reduceintervals,shift17,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dotArray;
  @SuppressWarnings("unchecked")
  private void initdotArray() {
    dotArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift18,reducenormalLetter,shift18,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift18,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift18,shift18,reduceregexCat,branch0,branch0,shift18,reducehatEmpty,reducehatPresent,shift18,branch0,shift18,shift18,branch0,branch0,shift18,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] stringLetterArray;
  @SuppressWarnings("unchecked")
  private void initstringLetterArray() {
    stringLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift21,reducestringSpecialLetter,reducestringLetter,reducespecialOrStringLetter,shift21,branch0,reducestring,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] slashArray;
  @SuppressWarnings("unchecked")
  private void initslashArray() {
    slashArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,branch0,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,reduceregexOr,reduceregexCat,branch0,branch0,branch0,branch0,branch0,branch0,shift49,branch0,branch0,branch0,branch0,reducemainRegex,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] integerArray;
  @SuppressWarnings("unchecked")
  private void initintegerArray() {
    integerArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift33,branch0,branch0,shift36,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbracArray;
  @SuppressWarnings("unchecked")
  private void initrbracArray() {
    rbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift34,branch0,shift38,shift37,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] normalLetterArray;
  @SuppressWarnings("unchecked")
  private void initnormalLetterArray() {
    normalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift1,reducenormalLetter,shift1,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift1,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift1,shift1,reduceregexCat,branch0,branch0,shift1,reducehatEmpty,reducehatPresent,shift1,branch0,shift1,shift1,branch0,branch0,shift1,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] questionArray;
  @SuppressWarnings("unchecked")
  private void initquestionArray() {
    questionArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift31,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,shift31,shift31,branch0,branch0,shift31,branch0,branch0,branch0,branch0,branch0,shift31,branch0,branch0,shift31,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbracArray;
  @SuppressWarnings("unchecked")
  private void initlbracArray() {
    lbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift32,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,shift32,shift32,branch0,branch0,shift32,branch0,branch0,branch0,branch0,branch0,shift32,branch0,branch0,shift32,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] specialLetterArray;
  @SuppressWarnings("unchecked")
  private void initspecialLetterArray() {
    specialLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift3,reducenormalLetter,shift3,reducenormalSpecialLetter,reduceregexMacro,shift7,shift7,reduceintervalSpecialLetter,reduceintervalLetter,reduceinterval,reduceintervalSingleton,shift7,reduceintervalSet,shift7,reduceregexIntervalNegate,reduceintervals,shift7,reduceregexInterval,reduceregexAny,shift20,reducestringSpecialLetter,reducestringLetter,reducespecialOrStringLetter,shift20,reduceregexString,reducestring,reduceregexLetter,shift3,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift3,shift3,reduceregexCat,branch0,branch0,shift3,reducehatEmpty,reducehatPresent,shift3,branch0,shift3,shift3,branch0,branch0,shift3,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] commaArray;
  @SuppressWarnings("unchecked")
  private void initcommaArray() {
    commaArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift35,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] __eof__Array;
  @SuppressWarnings("unchecked")
  private void init__eof__Array() {
    __eof__Array=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,branch0,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,reduceregexOr,reduceregexCat,accept,accept,reducemacro,branch0,branch0,branch0,reducefollowEmpty,branch0,reducefollowRegex,reducefollowDollar,reduceinitial,reducemainRegex,accept,accept};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] nameArray;
  @SuppressWarnings("unchecked")
  private void initnameArray() {
    nameArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift4,reducenormalLetter,shift4,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift4,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift4,shift4,reduceregexCat,branch0,branch0,shift4,reducehatEmpty,reducehatPresent,shift4,branch0,shift4,shift4,branch0,branch0,shift4,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] pipeArray;
  @SuppressWarnings("unchecked")
  private void initpipeArray() {
    pipeArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,shift39,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,reduceregexOr,reduceregexCat,branch0,branch0,shift39,branch0,branch0,branch0,branch0,branch0,shift39,branch0,branch0,shift39,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dollarArray;
  @SuppressWarnings("unchecked")
  private void initdollarArray() {
    dollarArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reducenormalLetter,branch0,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,branch0,branch0,branch0,branch0,reduceregexString,branch0,reduceregexLetter,branch0,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,branch0,reduceregexOr,reduceregexCat,branch0,branch0,branch0,branch0,branch0,branch0,shift51,branch0,branch0,branch0,branch0,reducemainRegex,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoteArray;
  @SuppressWarnings("unchecked")
  private void initquoteArray() {
    quoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift19,reducenormalLetter,shift19,reducenormalSpecialLetter,reduceregexMacro,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexAny,branch0,reducestringSpecialLetter,reducestringLetter,reducespecialOrStringLetter,shift24,reduceregexString,reducestring,reduceregexLetter,shift19,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,shift19,shift19,reduceregexCat,branch0,branch0,shift19,reducehatEmpty,reducehatPresent,shift19,branch0,shift19,shift19,branch0,branch0,shift19,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] minusArray;
  @SuppressWarnings("unchecked")
  private void initminusArray() {
    minusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceintervalSpecialLetter,reduceintervalLetter,branch0,shift11,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchArrayTable;
  @SuppressWarnings("unchecked")
  private void initBranchArrayTable() {
    branchArrayTable=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{error0,reducenormalLetter,error0,reducenormalSpecialLetter,reduceregexMacro,error0,error0,error0,error0,error0,error0,error0,error0,error0,reduceregexIntervalNegate,error0,error0,reduceregexInterval,reduceregexAny,error0,error0,error0,error0,error0,reduceregexString,error0,reduceregexLetter,error0,reduceregexStar,reduceregexPlus,reduceregexPar,reduceregexOptional,error0,error0,reduceregexTimes,error0,error0,reduceregexRange,reduceregexAtLeast,error0,reduceregexOr,reduceregexCat,exit,exit,reducemacro,error0,error0,error0,reducefollowEmpty,error0,reducefollowRegex,reducefollowDollar,reduceinitial,reducemainRegex,exit,exit};
  }

  private final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> table;
  
  public static final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> createTable() {
    return new ParserDataTable().table;
  }

  private final AcceptAction<TerminalEnum,ProductionEnum,VersionEnum> accept;
  private final ExitAction<TerminalEnum,ProductionEnum,VersionEnum> exit;

  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAtLeast;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAny;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinitial;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexString;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemainRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexIntervalNegate;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexStar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatPresent;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexCat;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSet;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexRange;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexMacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervals;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOr;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOptional;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexTimes;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSingleton;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexInterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowDollar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducespecialOrStringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPlus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestring;

  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift4;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift3;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift1;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift34;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift31;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift32;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift20;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift18;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift38;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift8;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift49;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift11;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift6;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift2;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift28;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift30;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift39;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift46;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift24;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift14;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift36;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift51;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift19;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift17;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift33;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift7;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift5;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift29;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift37;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift21;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift35;


  private final ErrorAction<TerminalEnum,ProductionEnum,VersionEnum> error0;

  private final BranchAction<TerminalEnum,ProductionEnum,VersionEnum> branch0;

}
