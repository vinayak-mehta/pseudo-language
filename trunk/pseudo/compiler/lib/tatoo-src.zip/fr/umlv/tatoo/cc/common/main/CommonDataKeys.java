package fr.umlv.tatoo.cc.common.main;

import fr.umlv.tatoo.cc.common.extension.ExtensionBus.DataKey;

public class CommonDataKeys {
  public static final DataKey<GeneratorBean> bean=
    new DataKey<GeneratorBean>();
}
