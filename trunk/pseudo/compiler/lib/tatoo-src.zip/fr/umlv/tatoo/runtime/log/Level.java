package fr.umlv.tatoo.runtime.log;

public enum Level {
  ALL, FINEST, FINE, INFO, WARNING, SEVERE,NONE
}
