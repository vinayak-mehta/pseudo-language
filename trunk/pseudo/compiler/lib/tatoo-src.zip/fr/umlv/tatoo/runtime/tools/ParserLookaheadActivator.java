/*
 * Created on 13 juil. 2005
 */
package fr.umlv.tatoo.runtime.tools;

import java.lang.reflect.Array;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import fr.umlv.tatoo.runtime.lexer.RuleActivator;
import fr.umlv.tatoo.runtime.parser.LookaheadMap;
import fr.umlv.tatoo.runtime.parser.Parser;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.util.ReadOnlyIntStack;
import fr.umlv.tatoo.runtime.util.Utils;

/** A {@link RuleActivator rule activator} that use parser lookaheads. 
 *  For each parser state, the implementation used the set of possible terminal
 *  given by the parser to find the set corresponding rules to activate. 
 * 
 *  This implementation supposes that rules and terminals
 *  are specified using enums. In order to improve speed
 *  and memory usage, this activator internally
 *  uses {@link EnumSet} and {@link EnumMap}.
 *  
 *  This implementation pre-calculate all possibles rule set
 *  for all parser state.
 * 
 * @param <R> type of rule (must be an enum).
 * @param <T> type of terminal (must be an enum).
 * @param <V> type of version (must be an enum).
 * 
 * @author Remi Forax
 */
//TODO Remi try to see if some lists can be shared
public class ParserLookaheadActivator<R,T,V>
  implements RuleActivator<R> {
  
  private final ReadOnlyIntStack stateStack;
  private final Map<V,R[][]> rulesArrayMap;
  private final Parser<T,?,?,V> parser;
  
  private static <R> Class<? extends R> guessRuleClass(ToolsTable<R,?> toolsTable) {
    Set<? extends R> set=toolsTable.getDiscardSet();
    if (!set.isEmpty())
      return pickOneItem(set);
    set=toolsTable.getSpawnSet();
    if (!set.isEmpty())
      return pickOneItem(set);
    set=toolsTable.getUnconditionalRuleSet();
    if (!set.isEmpty())
      return pickOneItem(set);
    set=toolsTable.getRuleToTerminalMap().keySet();
    if (!set.isEmpty())
      return pickOneItem(set);
    throw new IllegalStateException("no rule defined");
  }
  
  @SuppressWarnings("unchecked")
  private static <R> Class<? extends R> pickOneItem(Set<? extends R> set) {
    //FIXME Remi: why cast is needed, need investigation
    return (Class<? extends R>)set.iterator().next().getClass();
  }
  
  public ParserLookaheadActivator(Parser<T,?,?,V> parser,
      ToolsTable<R,T> toolsTable,Map<V,R[][]> container) {    
    this(parser,
      Utils.inverse(toolsTable.getRuleToTerminalMap()),
      toolsTable.getUnconditionalRuleSet(),
      container,
      guessRuleClass(toolsTable));
  }
  
  /**
   * @param parser a simple parser
   * @param container the container used by this activator to store the map
   */
  public ParserLookaheadActivator(Parser<T,?,?,V> parser,
      Map<T,? extends Set<? extends R>> terminalMap, Set<? extends R> unconditionalRuleSet,
      Map<V,R[][]> container, Class<? extends R> ruleClass) {    
    
    LookaheadMap<? extends T,? super V> lookaheadMap=parser.getLookaheadMap();
    if (parser.getLookaheadMap()==null)
      throw new IllegalArgumentException("The parser must be constructed with a lookahead map");
    
    
    ParserTable<T,?,?,V> table=parser.getTable();
    int stateNb=table.getStateNb();
    
    @SuppressWarnings("unchecked") R[] emptyArray=
      (R[])Array.newInstance(ruleClass,0);
    
    for(V version:table.getVersions()) {
      @SuppressWarnings("unchecked") R[][] rulesArray = (R[][])Array.newInstance(emptyArray.getClass(), stateNb);
      for(int state=0;state<stateNb;state++) {
        HashSet<R> rules=new HashSet<R>();
        rules.addAll(unconditionalRuleSet);
        
        for(T terminal:lookaheadMap.getLookahead(state,version)) {
          Set<? extends R> toAdd = terminalMap.get(terminal);
          if (toAdd!=null)
            rules.addAll(toAdd);
        }
        rulesArray[state]=rules.toArray(emptyArray);
      }
      container.put(version,rulesArray);
    }
    
    this.rulesArrayMap=container;
    this.parser=parser;
    this.stateStack=parser.getStateStack();
  }

  public R[] activeRules() {
    return rulesArrayMap.get(parser.getVersion())[stateStack.last()];
  }
}
