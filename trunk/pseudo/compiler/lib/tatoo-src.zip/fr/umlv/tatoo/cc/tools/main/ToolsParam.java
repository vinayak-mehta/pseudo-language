/*
 * Created on 13 nov. 2005
 *
 */
package fr.umlv.tatoo.cc.tools.main;

public interface ToolsParam {
  public boolean isGenerateAST();
  public void setGenerateAST(boolean generateAST);
}