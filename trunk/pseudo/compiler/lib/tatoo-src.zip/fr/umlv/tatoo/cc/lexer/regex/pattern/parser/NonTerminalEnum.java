package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum NonTerminalEnum {
  pattern,
macro,
hatOpt,
main,
follow,
regex,
specialOrNormalLetter,
string,
specialOrStringLetter,
intervals,
interval,
specialOrIntervalLetter
;
}