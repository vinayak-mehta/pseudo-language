package fr.umlv.tatoo.cc;

public class Tatoo {
  // update3
  private Tatoo() {
    // can't be instantiated
  }
  
  public enum Status {
    ALPHA, BETA, RC, RELEASE;
  }
  
  public static String version() {
    return "Tatoo version "+major()+'.'+minor()+
      ' '+status().name().toLowerCase()+' '+revision()
      +" ("+date()+')';
  }
  
  public static int major() {
    return 4;
  }
  
  public static int minor() {
    return 2;
  }
  
  public static Status status() {
    return Status.BETA;
  }
  
  public static int revision() {
    try {
      return Integer.parseInt(shrink(11,"$Revision: 2040 $"));
    } catch (NumberFormatException e) {
      return -1;
    }
  }
  
  public static String date() {
    return shrink(7,"$Date: 2009-10-09 14:26:42 +0200 (ven., 09 oct. 2009) $");
  }
  
  private static String shrink(int index,String text) {
    return text.substring(index,text.length()-2);
  }
}
