package fr.umlv.tatoo.runtime.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Utils {
  /** Inverse a Map.
   * @param <K> type of the key.
   * @param <V> type of the value.
   * 
   * @param map a map
   * @return a new map which for every values of the map taken as argument
   *         associate the set of all keys.
   */
  public static <K,V> Map<V,Set<K>> inverse(Map<? extends K,? extends V> map) {
    HashMap<V,Set<K>> newMap=new HashMap<V,Set<K>>();
    for(Map.Entry<? extends K,? extends V> entry:map.entrySet()) {
      V second=entry.getValue();
      Set<K> set=newMap.get(second);
      if (set==null) {
        set=new HashSet<K>();
        newMap.put(second,set);
      }
      set.add(entry.getKey());
    }
    return newMap;
  }
}
